/*
Name: Devika Ashok
Date:07/06/24
Description:WAP to replace each string of one or more blanks by a single blank
Sample input:Pointers         are      sharp           knives.
Sample output:Pointers are sharp knives.
*/
#include <stdio.h>
#include <string.h>

void replace_blank(char []); //function prototype

int main()
{
    char str[100];
    
    //printf("Enter the string with more spaces in between two words\n");
    scanf("%[^\n]", str); //read input from user
    
    replace_blank(str); //function call
    
    printf("%s\n", str);
}
void replace_blank(char str[])
{
    //int len=strlen(str);
   // while(str[i] !='\0')
    int i=0;
    while(str[i] !='\0') // start the loop ,until null present the loop will run
    {
        if(str[i]==' ' || str[i]=='\t') //check whether space or tab space is present
        {
            if(str[i+1]==' '|| str[i]=='\t') //if adjacent element of i is also space or tab shift other elements to that position
            {
                for(int j=i+1;str[j]!='\0';j++) //shift elements to left 
                {
                    str[j]=str[j+1];
                }
            
                
            }
            else
            {
                i++; //else increment the i value
            }
        }
        else
        {
            i++; //if there is no space or tab increment the i value
        }
    }
        
    
    
}